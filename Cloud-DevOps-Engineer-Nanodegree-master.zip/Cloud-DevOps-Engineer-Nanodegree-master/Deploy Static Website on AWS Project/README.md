## Project 1: Deploy Static Website on AWS  


### CloudFront Distribution:

> http://dpseubs4bpnux.cloudfront.net/index.html


### Site Url: 

> http://udacity-cloud-devops-website.s3.amazonaws.com/index.html